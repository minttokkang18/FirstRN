import { Text } from 'react-native';

function FavoritesScreen() {
  return <Text>이곳은 메모장입니다.</Text>; // 좌측 드로어 내비를 활용한 목록 언 매모 탭 설정
}

export default FavoritesScreen;
