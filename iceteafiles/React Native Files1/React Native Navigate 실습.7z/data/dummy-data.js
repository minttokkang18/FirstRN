import Category from '../models/category';
import Meal from '../models/meal';

export const CATEGORIES = [ // 카테코리 안에 항목 별 이름 지정하기
  new Category('c1', '영산대 공지사항', 'white'), // 셀렉 박스 스타일
  new Category('c2', '사용자 정보', 'white'),
  new Category('c3', '울산 방면 조회', 'white'),
  new Category('c4', '부산 방면 조회', 'white'),
];

export const MEALS = [ // 배열 c1 안에 목록 값 지정
  new Meal(
    'm1',
    ['c1'],
    '영산대학교 공지사항',
    ' ',
    ' ',
    'https://i.ibb.co/7pZKzpG/ysu.png', // 각 배너 별 이미지 url 지정
    ' ',
    [
      '공지사항 출력', // 서브 주제 출력
      '메인화면 출력',
      '데이터 입력',
    ],
    [
      '단계별로 진행',
      '공지사항 진행',
      '데이터 받기',
    ],
    false, // 결과 값 true, false
    true,
    true,
    true
  ),

  new Meal(
    'm2',
    ['c2'],
    '사용자 정보',
    ' ',
    ' ',
    'https://cdn.pixabay.com/photo/2016/03/23/22/26/user-1275780_960_720.png',
    ' ',
    [
      '실시간으로 사용자 정보 업로드',
      '데이터를 받는 장치',
      '확고한 시스템',
    ],
    [
      '준비화면',
      '앱 구동 진입',
      '스크롤뷰 전환',
      '플랫리스트 전환', 
      '획득',
    ],
    false,
    false,
    false,
    false
  ),

  new Meal(
    'm3',
    ['c3'],
    '울산 스쿨버스',
    ' ',
    ' ',
    'https://i.ibb.co/BntnsGn/ulsan.jpg',
    ' ',
    [
      '111111',
    ],
    [
      '123'
    ],
    false,
    false,
    false,
    true
  ),

  new Meal(
    'm4',
    ['c4'],
    '부산 스쿨버스 방면',
    ' ',
    ' ',
    'https://i.ibb.co/m4wf5VL/busan.jpg',
    ' ',
    [
      '테스트',
    ],
    [
      '123'
    ],
    false,
    false,
    false,
    false
  ),
];
