import { View, Text, StyleSheet } from 'react-native';

function Subtitle({children}) { // 서브 타이틀 관리
  return (
    <View style={styles.subtitleContainer}>
      <Text style={styles.subtitle}>{children}</Text>
    </View>
  );
}

export default Subtitle;

const styles = StyleSheet.create({
  subtitle: {
    color: '#6667ab', // 서브 타이틀 배경 색 지정
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  subtitleContainer: {
    padding: 6,
    marginHorizontal: 12,
    marginVertical: 4,
    borderBottomColor: 'yellow', // 선 강조 표시
    borderBottomWidth: 2,
  },
});
