class Category { // 클래스에서 메소드 전달
    constructor(id, title, color) {
      this.id = id;
      this.title = title;
      this.color = color;
    }
  }
  
  export default Category;
  