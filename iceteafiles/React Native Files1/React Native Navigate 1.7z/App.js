import * as React from 'react';
import { Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import TextSave from './components/TextSave';
import WiseU from './components/WiseU'

function Feed() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Feed!</Text>
    </View>
  );
}

function Profile() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>사용자 정보를 불러옵니다.</Text>
    </View>
  );
}

function Notifications() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>최신 뉴스를 가져옵니다.</Text>
    </View>
  );
}

const Tab = createBottomTabNavigator();

function MyTabs() {
  return (
    <Tab.Navigator
      initialRouteName="Feed"
      screenOptions={{
        tabBarActiveTintColor: '#6667ab',
      }}
    >
        <Tab.Screen
        name="와이즈유 영산대학교"
        component={WiseU}
        options={{
          tabBarLabel: '메인화면',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="cellphone-check" color={color} size={size} />
          ),
        }}
      />
         <Tab.Screen
        name="사용자"
        component={Profile}
        options={{
          tabBarLabel: '사용자',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="emoticon-excited" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="최신뉴스"
        component={Notifications}
        options={{
          tabBarLabel: '알림',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="message-badge" color={color} size={size} />
          ),
        }}
      />
        <Tab.Screen
        name="메모"
        component={TextSave}
        options={{
          tabBarLabel: '노트',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="content-save" color={color} size={size} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <MyTabs />
    </NavigationContainer>
  );
}
