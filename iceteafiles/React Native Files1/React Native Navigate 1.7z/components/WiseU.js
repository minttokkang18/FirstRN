import React from 'react';
import { StyleSheet, Button, View, SafeAreaView, Text, Alert, TextInput } from 'react-native';

const Separator = () => (
  <View style={styles.separator} />
);

const Wddsc = () => (
  <SafeAreaView style={styles.container}>
    
    <View>
    <Text style={styles.title}>
      영산대 스쿨버스 조회
      </Text>
    </View>
    <Separator />

    <View>
      <Text style={styles.title}>
      울산 노선도 조회하기
      </Text>
      <Button
        title="울산방향 클릭"
        color="#ff6f61"
        onPress={() => Alert.alert('울산으로 이동')}
      />
    </View>
    <Separator />
    <View>
      <Text style={styles.title}>
        부산 노선도 조회하기
      </Text>
      <Button
        title="부산방향 클릭"
        color="#6667ab"
        onPress={() => Alert.alert('부산으로 이동')}
      />
    </View>
    <Separator />
    <View>
      <Text style={styles.title}>
        사용자 정보 불러오기
      </Text>
      <Button
        title="프로필 수정"
        color="#34558b"
        onPress={() => Alert.alert('버튼을 누르지 않음')}
      />
    </View>
    <Separator />
    <View>
      <Text style={styles.title}>
        공지사항
      </Text>
      <View style={styles.fixToText}>
        <Button
          title="<-"
          color="#ff6f61"
          onPress={() => Alert.alert('왼쪽으로 이동합니다')}
        />
        <Button
          title="->"
          color="#ff6f61"
          onPress={() => Alert.alert('오른쪽으로 이동합니다')}
        />
      </View>
    </View>
  </SafeAreaView>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor:'#f5df4d',
    marginHorizontal: 16,
  },
  title: {
    textAlign: 'center',
    marginVertical: 8,
  },
  fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  separator: {
    marginVertical: 8,
    borderBottomColor: '#ff6f61',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
});

export default Wddsc;